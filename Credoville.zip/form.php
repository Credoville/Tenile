<?php
if(isset($_POST['Submit'])){
    $Fullname=$_POST['Fullname'];
    $Email=$_POST['Email'];
    $message=$_POST['message'];

    $mailTo="info@credoville.com";

    $headers="From:" .$Email;

    $txt="you have recieved e-mail from " .$Fullname ".\n\n" .$message;

    mail($mailTo, $txt, $headers);
    header("Locations= form.php?mailsend");
}
?>
